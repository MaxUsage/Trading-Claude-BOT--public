"""Bot wallet helpers. The private key is read from the environment only and
is never logged, printed, or sent anywhere except used to sign locally."""

_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"


def b58encode(data: bytes) -> str:
    n = int.from_bytes(data, "big")
    out = ""
    while n > 0:
        n, rem = divmod(n, 58)
        out = _ALPHABET[rem] + out
    pad = len(data) - len(data.lstrip(b"\x00"))
    return "1" * pad + out


def b58decode(text: str) -> bytes:
    n = 0
    for ch in text:
        n = n * 58 + _ALPHABET.index(ch)
    body = n.to_bytes((n.bit_length() + 7) // 8, "big") if n else b""
    pad = len(text) - len(text.lstrip("1"))
    return b"\x00" * pad + body


def load_keypair(b58_secret: str):
    """Returns a solders Keypair from a base58 64-byte secret."""
    from solders.keypair import Keypair  # imported lazily so tests need no solders
    return Keypair.from_bytes(b58decode(b58_secret))
