"""SQLite storage. State survives restarts (including the halt switch)."""
import sqlite3
import time
from typing import Any, Dict, List, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS state (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS positions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mint TEXT, symbol TEXT, strategy TEXT, decimals INTEGER,
  tokens_raw INTEGER, sol_in REAL, sol_out REAL DEFAULT 0,
  entry_price REAL, peak_price REAL, entry_liq REAL, last_price REAL,
  tp1_done INTEGER DEFAULT 0, tp2_done INTEGER DEFAULT 0,
  status TEXT DEFAULT 'open', opened_at REAL, closed_at REAL, dry_run INTEGER
);
CREATE TABLE IF NOT EXISTS trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, position_id INTEGER,
  side TEXT, mint TEXT, symbol TEXT, sol REAL, tokens_raw INTEGER,
  reason TEXT, signature TEXT, dry_run INTEGER
);
"""


class Store:
    def __init__(self, path: str):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)
        self.db.commit()

    # ---- key/value state ----
    def get(self, key: str, default: Optional[str] = None) -> Optional[str]:
        row = self.db.execute("SELECT value FROM state WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set(self, key: str, value: Any) -> None:
        self.db.execute("INSERT OR REPLACE INTO state(key,value) VALUES(?,?)", (key, str(value)))
        self.db.commit()

    def get_float(self, key: str, default: float = 0.0) -> float:
        v = self.get(key)
        return float(v) if v is not None else default

    # ---- positions ----
    def open_position(self, **p) -> int:
        cur = self.db.execute(
            """INSERT INTO positions(mint,symbol,strategy,decimals,tokens_raw,sol_in,
               entry_price,peak_price,entry_liq,opened_at,dry_run)
               VALUES(:mint,:symbol,:strategy,:decimals,:tokens_raw,:sol_in,
               :entry_price,:entry_price,:entry_liq,:opened_at,:dry_run)""",
            {**p, "opened_at": time.time()})
        self.db.commit()
        return cur.lastrowid

    def open_positions(self) -> List[sqlite3.Row]:
        return self.db.execute("SELECT * FROM positions WHERE status='open'").fetchall()

    def has_open(self, mint: str) -> bool:
        return self.db.execute("SELECT 1 FROM positions WHERE mint=? AND status='open'",
                               (mint,)).fetchone() is not None

    def recently_traded(self, mint: str, within_s: float = 6 * 3600) -> bool:
        """Never re-enter a token we already traded recently."""
        return self.db.execute("SELECT 1 FROM positions WHERE mint=? AND opened_at>?",
                               (mint, time.time() - within_s)).fetchone() is not None

    def update_position(self, pid: int, **fields) -> None:
        cols = ", ".join(f"{k}=?" for k in fields)
        self.db.execute(f"UPDATE positions SET {cols} WHERE id=?", (*fields.values(), pid))
        self.db.commit()

    def log_trade(self, **t) -> None:
        self.db.execute(
            """INSERT INTO trades(ts,position_id,side,mint,symbol,sol,tokens_raw,reason,signature,dry_run)
               VALUES(:ts,:position_id,:side,:mint,:symbol,:sol,:tokens_raw,:reason,:signature,:dry_run)""",
            {"ts": time.time(), **t})
        self.db.commit()

    def stats(self) -> Dict[str, float]:
        rows = self.db.execute(
            "SELECT sol_in, sol_out FROM positions WHERE status='closed'").fetchall()
        wins = [r for r in rows if r["sol_out"] > r["sol_in"]]
        net = sum(r["sol_out"] - r["sol_in"] for r in rows)
        return {"closed": len(rows), "wins": len(wins), "net_sol": net}

    def recent_trades(self, limit: int = 50) -> List[Dict]:
        rows = self.db.execute("SELECT * FROM trades ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    def recent_closed(self, limit: int = 20) -> List[Dict]:
        rows = self.db.execute(
            "SELECT * FROM positions WHERE status='closed' ORDER BY closed_at DESC LIMIT ?",
            (limit,)).fetchall()
        return [dict(r) for r in rows]

    def loss_streak(self, strategy: str, limit: int = 10):
        """(consecutive losses counting back from the latest closed trade, closed_at of latest)."""
        rows = self.db.execute(
            "SELECT sol_in, sol_out, closed_at FROM positions WHERE status='closed' AND strategy=? "
            "ORDER BY closed_at DESC LIMIT ?", (strategy, limit)).fetchall()
        streak = 0
        for r in rows:
            if r["sol_out"] < r["sol_in"]:
                streak += 1
            else:
                break
        return streak, (rows[0]["closed_at"] if rows else 0)
