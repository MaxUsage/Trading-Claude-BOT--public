"""Local control API for the Chrome extension.

Security model:
- Binds to 127.0.0.1 only (not reachable from other computers).
- Every request needs the secret X-Token header (API_TOKEN in .env).
- Host header must be localhost/127.0.0.1 (blocks DNS-rebinding tricks).
- No CORS headers are sent, so ordinary websites cannot read responses;
  the extension is allowed through its own host permission.
- It can pause/resume/stop/reset. It can NOT move funds or reveal keys.
"""
import hmac
import json
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Dict, Tuple

from store import Store


def _pos_view(p: Dict) -> Dict:
    dec = p["decimals"] or 0
    ui = (p["tokens_raw"] or 0) / (10 ** dec)
    last = p.get("last_price") or 0
    entry = p.get("entry_price") or 0
    return {
        "id": p["id"], "mint": p["mint"], "symbol": p["symbol"], "strategy": p["strategy"],
        "sol_in": p["sol_in"], "sol_out": p["sol_out"], "value_sol": ui * last,
        "pnl_pct": (last / entry - 1) if entry and last else None,
        "tp1_done": bool(p["tp1_done"]), "tp2_done": bool(p["tp2_done"]),
        "opened_at": p["opened_at"], "dry_run": bool(p["dry_run"]),
    }


def handle(store: Store, method: str, path: str) -> Tuple[int, Dict]:
    """Pure-ish request handler (easy to test)."""
    now = time.time()
    if method == "GET" and path == "/status":
        last = store.get_float("last_cycle", 0)
        return 200, {
            "running": (now - last) < 180 if last else False,
            "seconds_since_check": round(now - last) if last else None,
            "mode": store.get("mode", "unknown"),
            "paused": store.get("paused") == "1",
            "halted": store.get("halted") == "1",
            "halt_reason": store.get("halt_reason", ""),
            "equity": store.get_float("equity"),
            "peak": store.get_float("peak_equity"),
            "start": store.get_float("start_equity"),
            "free_sol": store.get_float("free_sol"),
            "open_positions": len(store.open_positions()),
            "stats": store.stats(),
            "last_error": store.get("last_error", ""),
        }
    if method == "GET" and path == "/positions":
        return 200, {"positions": [_pos_view(dict(p)) for p in store.open_positions()]}
    if method == "GET" and path == "/trades":
        return 200, {"trades": store.recent_trades(50)}
    if method == "POST" and path == "/pause":
        store.set("paused", 1); return 200, {"ok": True}
    if method == "POST" and path == "/resume":
        store.set("paused", 0); return 200, {"ok": True}
    if method == "POST" and path == "/reset":
        store.set("reset_requested", 1); return 200, {"ok": True, "note": "applies next cycle"}
    if method == "POST" and path == "/shutdown":
        store.set("shutdown", 1); return 200, {"ok": True}
    return 404, {"error": "not found"}


def make_server(cfg, port=None):
    token = cfg.api_token

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _reply(self, code, obj):
            body = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _serve(self, method):
            host = (self.headers.get("Host") or "").split(":")[0]
            if host not in ("127.0.0.1", "localhost"):
                return self._reply(403, {"error": "bad host"})
            if not token or not hmac.compare_digest(self.headers.get("X-Token", ""), token):
                return self._reply(401, {"error": "bad token"})
            store = Store(cfg.db_path)  # own connection per request (thread-safe)
            try:
                code, obj = handle(store, method, self.path.split("?")[0])
            finally:
                store.db.close()
            self._reply(code, obj)

        def do_GET(self):
            self._serve("GET")

        def do_POST(self):
            self._serve("POST")

    return ThreadingHTTPServer(("127.0.0.1", cfg.api_port if port is None else port), Handler)
