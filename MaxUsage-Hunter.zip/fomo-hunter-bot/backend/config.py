"""Configuration. Everything comes from environment variables / the .env file.

Safety defaults: DRY_RUN is ON. Live trading needs BOTH DRY_RUN=false AND
I_UNDERSTAND_REAL_MONEY=yes.
"""
import os
from dataclasses import dataclass

WSOL = "So11111111111111111111111111111111111111112"
LAMPORTS = 1_000_000_000


def load_dotenv(path: str = ".env") -> None:
    """Tiny .env parser (no extra dependency). Existing env vars win."""
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            os.environ.setdefault(key.strip(), val.strip().strip('"').strip("'"))


def _f(name, default):
    return float(os.getenv(name, default))


def _i(name, default):
    return int(os.getenv(name, default))


def _b(name, default):
    return os.getenv(name, str(default)).strip().lower() in ("1", "true", "yes")


@dataclass
class Config:
    # --- mode ---
    dry_run: bool
    confirm_real_money: bool
    # --- secrets (never logged) ---
    rpc_url: str
    jupiter_api_key: str
    bot_private_key: str
    telegram_token: str
    telegram_chat_id: str
    # --- risk ---
    trade_fraction: float      # share of free balance per trade (0.5 = 50%)
    reserve_sol: float         # always keep this much SOL for fees/rent
    min_trade_sol: float
    max_trade_sol: float       # hard cap per trade (your 5 SOL limit)
    max_positions: int
    stop_loss_pct: float       # 0.25 = sell everything at -25%
    tp1_pct: float
    tp1_sell_frac: float
    tp2_pct: float
    tp2_sell_frac: float       # fraction of what remains after TP1
    trail_pct: float           # trailing stop on the remainder, after TP1
    max_dd_from_peak: float    # 0.40 = halt at 40% below peak equity
    max_loss_from_start: float # 0.40 = halt at 40% below starting equity
    buy_slippage_bps: int
    sell_slippage_bps: int
    # --- loop ---
    poll_seconds: int
    dry_run_start_sol: float
    db_path: str
    allow_token_2022: bool
    api_token: str
    api_port: int
    sweep_address: str         # where profit shares are sent (fixed in .env, not changeable remotely)
    sweep_pct: float           # share of each winning trade's profit that is sent out
    min_sweep_sol: float
    min_score: int             # entry score threshold (0-100)
    min_confirmations: int     # consecutive cycles a token must keep passing
    max_chase: float           # skip if price rose more than this since first sighting
    loss_streak_pause: int     # pause a strategy after this many losses in a row


def load() -> Config:
    load_dotenv()
    return Config(
        dry_run=_b("DRY_RUN", True),
        confirm_real_money=os.getenv("I_UNDERSTAND_REAL_MONEY", "").strip().lower() == "yes",
        rpc_url=os.getenv("RPC_URL") or "https://api.mainnet-beta.solana.com",
        jupiter_api_key=os.getenv("JUPITER_API_KEY", ""),
        bot_private_key=os.getenv("BOT_PRIVATE_KEY", ""),
        telegram_token=os.getenv("TELEGRAM_BOT_TOKEN", ""),
        telegram_chat_id=os.getenv("TELEGRAM_CHAT_ID", ""),
        trade_fraction=_f("TRADE_FRACTION", 0.50),
        reserve_sol=_f("RESERVE_SOL", 0.01),
        min_trade_sol=_f("MIN_TRADE_SOL", 0.01),
        max_trade_sol=_f("MAX_TRADE_SOL", 5.0),
        max_positions=_i("MAX_POSITIONS", 2),
        stop_loss_pct=_f("STOP_LOSS_PCT", 0.25),
        tp1_pct=_f("TP1_PCT", 0.30),
        tp1_sell_frac=_f("TP1_SELL_FRAC", 0.50),
        tp2_pct=_f("TP2_PCT", 0.60),
        tp2_sell_frac=_f("TP2_SELL_FRAC", 0.50),
        trail_pct=_f("TRAIL_PCT", 0.20),
        max_dd_from_peak=_f("MAX_DD_FROM_PEAK", 0.40),
        max_loss_from_start=_f("MAX_LOSS_FROM_START", 0.40),
        buy_slippage_bps=_i("BUY_SLIPPAGE_BPS", 300),
        sell_slippage_bps=_i("SELL_SLIPPAGE_BPS", 1000),
        poll_seconds=_i("POLL_SECONDS", 60),
        dry_run_start_sol=_f("DRY_RUN_START_SOL", 0.1),
        db_path=os.getenv("DB_PATH", "bot.db"),
        allow_token_2022=_b("ALLOW_TOKEN_2022", False),
        api_token=os.getenv("API_TOKEN", ""),
        api_port=_i("API_PORT", 8787),
        sweep_address=os.getenv("SWEEP_ADDRESS", "").strip(),
        sweep_pct=_f("SWEEP_PCT", 0.30),
        min_sweep_sol=_f("MIN_SWEEP_SOL", 0.01),
        min_score=_i("MIN_SCORE", 60),
        min_confirmations=_i("MIN_CONFIRMATIONS", 2),
        max_chase=_f("MAX_CHASE", 0.15),
        loss_streak_pause=_i("LOSS_STREAK_PAUSE", 4),
    )


def live_trading_enabled(cfg: Config) -> bool:
    return (not cfg.dry_run) and cfg.confirm_real_money
