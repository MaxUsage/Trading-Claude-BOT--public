"""Entry filters. Pure functions on a DexScreener pair dict -> (ok, reasons).

IMPORTANT HONESTY NOTES
- 'Graduated' has no dedicated DexScreener endpoint. We approximate it:
  Solana pair on PumpSwap/Raydium, mint address ending in 'pump', young pair.
  (The 'pump' suffix is a Pump.fun convention; treat it as a heuristic.)
- 'Trending' = real activity measured from pair data. DexScreener 'boosts'
  are PAID promotion, so they are only used to find candidates, never as a
  reason to buy.
- These thresholds are experimental starting points, not proven settings.
"""
import time
from typing import Dict, List, Optional, Tuple

GRAD_DEXES = {"pumpswap", "raydium"}


def _g(d: Dict, *path, default=0.0):
    for key in path:
        if not isinstance(d, dict) or key not in d or d[key] is None:
            return default
        d = d[key]
    return d


def age_minutes(pair: Dict, now_ms: Optional[int] = None) -> Optional[float]:
    created = pair.get("pairCreatedAt")
    if not created:
        return None
    now_ms = now_ms or int(time.time() * 1000)
    return (now_ms - created) / 60000.0


def evaluate_graduated(pair: Dict, now_ms: Optional[int] = None) -> Tuple[bool, List[str]]:
    fails = []
    mint = _g(pair, "baseToken", "address", default="")
    age = age_minutes(pair, now_ms)
    if pair.get("dexId") not in GRAD_DEXES:
        fails.append("not on PumpSwap/Raydium")
    if not mint.endswith("pump"):
        fails.append("mint does not end with 'pump'")
    if age is None or not (5 <= age <= 360):
        fails.append("pair age outside 5-360 min")
    if _g(pair, "liquidity", "usd") < 15_000:
        fails.append("liquidity < $15k")
    buys, sells = _g(pair, "txns", "m5", "buys"), _g(pair, "txns", "m5", "sells")
    if buys < 10:
        fails.append("fewer than 10 buys in 5m")
    if buys <= sells:
        fails.append("sells >= buys in 5m")
    if _g(pair, "priceChange", "h1") > 200:
        fails.append("already up >200% in 1h (pump likely exhausted)")
    if _g(pair, "priceChange", "m5") <= 0:
        fails.append("price not rising over 5m")
    mc = _g(pair, "marketCap") or _g(pair, "fdv")
    if not (20_000 <= mc <= 2_000_000):
        fails.append("market cap outside $20k-$2M")
    return (not fails), fails


def evaluate_trending(pair: Dict, now_ms: Optional[int] = None) -> Tuple[bool, List[str]]:
    fails = []
    age = age_minutes(pair, now_ms)
    if age is None or not (60 <= age <= 72 * 60):
        fails.append("pair age outside 1h-72h")
    if _g(pair, "liquidity", "usd") < 25_000:
        fails.append("liquidity < $25k")
    if _g(pair, "volume", "h1") < 50_000:
        fails.append("1h volume < $50k")
    buys, sells = _g(pair, "txns", "m5", "buys"), _g(pair, "txns", "m5", "sells")
    if buys + sells < 20:
        fails.append("fewer than 20 txns in 5m")
    if sells and buys / sells < 1.2:
        fails.append("buy/sell ratio < 1.2")
    if _g(pair, "priceChange", "m5") <= 0:
        fails.append("price not rising over 5m")
    h1 = _g(pair, "priceChange", "h1")
    if not (5 <= h1 <= 150):
        fails.append("1h change outside +5%..+150%")
    mc = _g(pair, "marketCap") or _g(pair, "fdv")
    if not (50_000 <= mc <= 5_000_000):
        fails.append("market cap outside $50k-$5M")
    return (not fails), fails


STRATEGIES = {"graduated": evaluate_graduated, "trending": evaluate_trending}


def rank_key(pair: Dict) -> float:
    """Higher = stronger recent buying pressure. Used only to order passers."""
    buys = _g(pair, "txns", "m5", "buys")
    sells = _g(pair, "txns", "m5", "sells")
    return buys - sells


def _lin(x, lo, hi, pts):
    """Linear points: 0 at lo or below, `pts` at hi or above."""
    if hi == lo:
        return 0.0
    return max(0.0, min(1.0, (x - lo) / (hi - lo))) * pts


def score_pair(pair: Dict, strategy: str, now_ms: Optional[int] = None):
    """Transparent 0-100 entry score. Returns (score, parts).
    Deterministic and unit-tested; thresholds are experimental, not proven.
      buy pressure 25 | volume acceleration 20 | pool depth 15
      momentum sanity 15 | txn activity 15 | age sweet-spot 10
    Penalties for wash-trading-like patterns (heuristics from aggregate data):
      volume far above liquidity (-20), dust-sized average trades (-15).
    """
    buys, sells = _g(pair, "txns", "m5", "buys"), _g(pair, "txns", "m5", "sells")
    txns = buys + sells
    vol5, vol1 = _g(pair, "volume", "m5"), _g(pair, "volume", "h1")
    liq = _g(pair, "liquidity", "usd")
    mc = _g(pair, "marketCap") or _g(pair, "fdv")
    m5 = _g(pair, "priceChange", "m5")
    age = age_minutes(pair, now_ms) or 0
    parts = {}

    parts["buy_pressure"] = _lin(buys / txns if txns else 0, 0.5, 0.8, 25)
    accel = (vol5 * 12 / vol1) if vol1 > 0 else 0
    parts["acceleration"] = _lin(accel, 0.7, 1.5, 20)
    parts["pool_depth"] = _lin(liq / mc if mc else 0, 0.02, 0.10, 15)
    if 1 <= m5 <= 15:
        parts["momentum"] = 15.0
    elif 15 < m5 <= 35:
        parts["momentum"] = 8.0
    else:
        parts["momentum"] = 0.0  # flat/falling or already chasing
    parts["activity"] = _lin(txns, 10, 30, 15)
    lo, hi = (10, 90) if strategy == "graduated" else (120, 24 * 60)
    parts["age"] = 10.0 if lo <= age <= hi else 0.0

    penalty = 0.0
    if liq > 0 and vol5 / liq > 3:
        penalty += 20
    if txns >= 10 and vol5 / txns < 5:
        penalty += 15
    parts["wash_penalty"] = -penalty
    return round(max(0.0, sum(parts.values())), 1), parts
