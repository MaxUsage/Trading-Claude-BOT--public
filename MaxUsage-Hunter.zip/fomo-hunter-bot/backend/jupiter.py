"""Jupiter Swap API v2 client (https://api.jup.ag/swap/v2).

Verified against Jupiter docs:
  GET  /order    params: inputMint, outputMint, amount, taker (optional),
                 slippageBps (optional). Without `taker` you get a quote and
                 no transaction (used here for price / sell checks).
                 Response includes `transaction` (base64) and `requestId`.
  POST /execute  body: {signedTransaction (base64), requestId}.
                 Response: status "Success"/"Failed", signature, code,
                 inputAmountResult, outputAmountResult.
All calls need the `x-api-key` header. Free tier = 1 request/second, so every
call is throttled to stay under that.
"""
import base64
import logging
import time
from typing import Dict, Optional

import requests

from config import WSOL

log = logging.getLogger("jupiter")
BASE = "https://api.jup.ag/swap/v2"
_last_call = [0.0]


def _throttle(min_gap: float = 1.15) -> None:
    wait = min_gap - (time.time() - _last_call[0])
    if wait > 0:
        time.sleep(wait)
    _last_call[0] = time.time()


def get_order(api_key: str, input_mint: str, output_mint: str, amount: int,
              taker: Optional[str] = None, slippage_bps: Optional[int] = None) -> Optional[Dict]:
    params = {"inputMint": input_mint, "outputMint": output_mint, "amount": str(int(amount))}
    if taker:
        params["taker"] = taker
    if slippage_bps is not None:
        params["slippageBps"] = str(slippage_bps)
    _throttle()
    try:
        r = requests.get(BASE + "/order", params=params,
                         headers={"x-api-key": api_key}, timeout=20)
        if r.status_code != 200:
            log.warning("order failed %s: %s", r.status_code, r.text[:200])
            return None
        return r.json()
    except Exception as exc:
        log.warning("order request error: %s", exc)
        return None


def sign_transaction(tx_b64: str, keypair) -> str:
    """Signs only OUR signature slot (Jupiter routes can contain other
    signers, e.g. market makers), leaving theirs untouched."""
    from solders.message import to_bytes_versioned
    from solders.transaction import VersionedTransaction

    tx = VersionedTransaction.from_bytes(base64.b64decode(tx_b64))
    msg = tx.message
    n_signers = msg.header.num_required_signatures
    keys = list(msg.account_keys)[:n_signers]
    me = keypair.pubkey()
    if me not in keys:
        raise ValueError("bot wallet is not a required signer of this transaction")
    sigs = list(tx.signatures)
    sigs[keys.index(me)] = keypair.sign_message(to_bytes_versioned(msg))
    signed = VersionedTransaction.populate(msg, sigs)
    return base64.b64encode(bytes(signed)).decode()


def execute(api_key: str, signed_b64: str, request_id: str) -> Optional[Dict]:
    _throttle()
    try:
        r = requests.post(BASE + "/execute",
                          json={"signedTransaction": signed_b64, "requestId": request_id},
                          headers={"x-api-key": api_key, "Content-Type": "application/json"},
                          timeout=60)
        if r.status_code != 200:
            log.warning("execute failed %s: %s", r.status_code, r.text[:200])
            return None
        return r.json()
    except Exception as exc:
        log.warning("execute error: %s", exc)
        return None


def swap_live(api_key: str, keypair, input_mint: str, output_mint: str,
              amount: int, slippage_bps: int) -> Optional[Dict]:
    """Order -> sign -> execute. Returns {'in': raw, 'out': raw, 'sig': str} or None."""
    order = get_order(api_key, input_mint, output_mint, amount,
                      taker=str(keypair.pubkey()), slippage_bps=slippage_bps)
    if not order or not order.get("transaction") or not order.get("requestId"):
        return None
    try:
        signed = sign_transaction(order["transaction"], keypair)
    except Exception as exc:
        log.error("signing failed: %s", exc)
        return None
    res = execute(api_key, signed, order["requestId"])
    if not res or res.get("status") != "Success":
        log.warning("swap not successful: %s", res)
        return None
    return {"in": int(res.get("inputAmountResult") or 0),
            "out": int(res.get("outputAmountResult") or 0),
            "sig": res.get("signature", "")}


def quote_out(api_key: str, input_mint: str, output_mint: str, amount: int,
              slippage_bps: int) -> Optional[int]:
    """Expected output amount (raw units) with no transaction built."""
    order = get_order(api_key, input_mint, output_mint, amount, None, slippage_bps)
    if not order:
        return None
    try:
        return int(order.get("outAmount"))
    except (TypeError, ValueError):
        return None


def sellability_check(api_key: str, mint: str, sol_lamports: int,
                      slippage_bps: int, min_roundtrip: float = 0.80):
    """Quote SOL -> token, then token -> SOL for the same tokens. If there is no
    sell route, or the round trip loses too much (fees, price impact, honeypot
    tax), the token fails. This is an estimate from quotes, not a guarantee."""
    tokens = quote_out(api_key, WSOL, mint, sol_lamports, slippage_bps)
    if not tokens:
        return False, "no buy route", 0
    back = quote_out(api_key, mint, WSOL, tokens, slippage_bps)
    if not back:
        return False, "no SELL route (possible honeypot)", tokens
    ratio = back / sol_lamports
    if ratio < min_roundtrip:
        return False, f"round trip returns only {ratio:.0%} of SOL", tokens
    return True, f"round trip {ratio:.0%}", tokens
