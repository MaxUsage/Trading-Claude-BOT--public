"""Deterministic risk rules. Pure functions, no network, fully unit-tested."""
from typing import Optional, Tuple


def position_size(free_sol: float, cfg) -> float:
    """SOL to spend on the next buy. 0.0 means 'do not trade'."""
    usable = free_sol - cfg.reserve_sol
    if usable <= 0:
        return 0.0
    size = min(usable * cfg.trade_fraction, cfg.max_trade_sol)
    if size < cfg.min_trade_sol:
        return 0.0
    return round(size, 6)


def should_halt(equity: float, peak: float, start: float, cfg) -> Tuple[bool, str]:
    """Kill switch. Stays halted until the user resets it manually."""
    if peak > 0 and equity <= peak * (1 - cfg.max_dd_from_peak):
        return True, f"equity {equity:.4f} is {cfg.max_dd_from_peak:.0%}+ below peak {peak:.4f}"
    if start > 0 and equity <= start * (1 - cfg.max_loss_from_start):
        return True, f"equity {equity:.4f} is {cfg.max_loss_from_start:.0%}+ below start {start:.4f}"
    return False, ""


def can_open(open_count: int, halted: bool, cfg) -> bool:
    return (not halted) and open_count < cfg.max_positions


def exit_decision(entry: float, price: float, peak: float,
                  tp1_done: bool, tp2_done: bool, cfg) -> Tuple[str, float, str]:
    """Returns (action, fraction_of_remaining_to_sell, reason).
    action is 'hold' or 'sell'.
    Order matters: stop-loss first, then take-profits, then trailing."""
    if entry <= 0 or price <= 0:
        return "hold", 0.0, "no valid price"
    pnl = price / entry - 1.0
    if pnl <= -cfg.stop_loss_pct:
        return "sell", 1.0, f"stop-loss ({pnl:+.1%})"
    if not tp1_done and pnl >= cfg.tp1_pct:
        return "sell", cfg.tp1_sell_frac, f"take-profit 1 ({pnl:+.1%})"
    if tp1_done and not tp2_done and pnl >= cfg.tp2_pct:
        return "sell", cfg.tp2_sell_frac, f"take-profit 2 ({pnl:+.1%})"
    if tp1_done and peak > 0 and price <= peak * (1 - cfg.trail_pct):
        return "sell", 1.0, f"trailing stop ({cfg.trail_pct:.0%} below peak)"
    return "hold", 0.0, ""


def liquidity_exit(entry_liq: Optional[float], liq: Optional[float]) -> bool:
    """Emergency exit if pool liquidity has collapsed by half or more."""
    if not entry_liq or liq is None:
        return False
    return liq < entry_liq * 0.5
