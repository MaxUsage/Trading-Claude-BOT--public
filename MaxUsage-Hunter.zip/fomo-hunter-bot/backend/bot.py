"""FOMO Hunter bot: main loop.

    python bot.py            run (DRY-RUN unless you explicitly enabled live)
    python bot.py --reset    clear the halt switch and re-baseline equity

Flow each cycle:
  1. read balance, price open positions, update equity / peak
  2. kill switch check (40% below peak or below start -> no new buys, ever,
     until you run --reset). Open positions are still managed and sold.
  3. exits: stop-loss, take-profits, trailing stop, liquidity collapse
  4. entries: DexScreener candidates -> strategy filter -> on-chain rug
     checks -> Jupiter sell-check -> buy ONE token per cycle
"""
import logging
import sys
import time
from typing import Dict

import requests

import config
import jupiter
import market
import risk
import security
import strategies
import sweep
from config import LAMPORTS, WSOL
from store import Store

log = logging.getLogger("bot")
DRY_FEE_SOL = 0.0005  # assumed network+priority fee per trade in dry-run


class Bot:
    def __init__(self, cfg: config.Config):
        self.cfg = cfg
        self.store = Store(cfg.db_path)
        self.live = config.live_trading_enabled(cfg)
        self.keypair = None
        self.address = ""
        self.rejected: Dict[str, float] = {}
        self.missing: Dict[int, int] = {}
        self.seen: Dict[str, Dict] = {}
        self.paused_strategies: Dict[str, bool] = {}

        if not cfg.dry_run and not cfg.confirm_real_money:
            sys.exit("DRY_RUN=false but I_UNDERSTAND_REAL_MONEY is not 'yes'. Refusing to start.")
        if not cfg.jupiter_api_key:
            sys.exit("JUPITER_API_KEY missing in .env (needed even for dry-run quotes).")
        if self.live:
            if not cfg.bot_private_key:
                sys.exit("BOT_PRIVATE_KEY missing in .env. Run make_wallet.py first.")
            self.keypair = __import__("wallet").load_keypair(cfg.bot_private_key)
            self.address = str(self.keypair.pubkey())
        if cfg.sweep_address and not sweep.valid_address(cfg.sweep_address):
            sys.exit("SWEEP_ADDRESS in .env is not a valid Solana address. Check it character by character.")
        if self.store.get("dry_sol") is None:
            self.store.set("dry_sol", cfg.dry_run_start_sol)

    # ------------------------------------------------------------ helpers
    def notify(self, text: str) -> None:
        log.info("NOTIFY: %s", text)
        c = self.cfg
        if c.telegram_token and c.telegram_chat_id:
            try:
                requests.post(f"https://api.telegram.org/bot{c.telegram_token}/sendMessage",
                              json={"chat_id": c.telegram_chat_id, "text": text}, timeout=10)
            except Exception as exc:
                log.warning("telegram failed: %s", exc)

    def free_sol(self):
        if self.live:
            return security.get_sol_balance(self.cfg.rpc_url, self.address)
        return self.store.get_float("dry_sol")

    # ------------------------------------------------------------ trading
    def buy(self, name: str, mint: str, pair: Dict, size: float, decimals: int) -> bool:
        lamports = int(size * LAMPORTS)
        if self.live:
            res = jupiter.swap_live(self.cfg.jupiter_api_key, self.keypair, WSOL, mint,
                                    lamports, self.cfg.buy_slippage_bps)
            if not res or res["out"] <= 0:
                log.warning("buy failed for %s", mint)
                return False
            tokens, spent, sig = res["out"], res["in"] / LAMPORTS, res["sig"]
        else:
            out = jupiter.quote_out(self.cfg.jupiter_api_key, WSOL, mint, lamports,
                                    self.cfg.buy_slippage_bps)
            if not out:
                return False
            tokens, spent, sig = out, size, "dry-run"
            self.store.set("dry_sol", self.store.get_float("dry_sol") - size - DRY_FEE_SOL)
        ui = tokens / (10 ** decimals)
        symbol = (pair.get("baseToken") or {}).get("symbol", "?")
        pid = self.store.open_position(
            mint=mint, symbol=symbol, strategy=name, decimals=decimals, tokens_raw=tokens,
            sol_in=spent, entry_price=spent / ui,
            entry_liq=(pair.get("liquidity") or {}).get("usd") or 0, dry_run=int(not self.live))
        self.store.log_trade(position_id=pid, side="buy", mint=mint, symbol=symbol, sol=spent,
                             tokens_raw=tokens, reason=f"{name} signal", signature=sig,
                             dry_run=int(not self.live))
        self.notify(f"{'[DRY] ' if not self.live else ''}BUY {symbol} ({name}) {spent:.4f} SOL\n"
                    f"https://dexscreener.com/solana/{mint}")
        return True

    def sell(self, p, frac: float, reason: str) -> None:
        amount = p["tokens_raw"] if frac >= 1 else int(p["tokens_raw"] * frac)
        if amount <= 0:
            self.store.update_position(p["id"], status="closed", closed_at=time.time())
            return
        if self.live:
            res = jupiter.swap_live(self.cfg.jupiter_api_key, self.keypair, p["mint"], WSOL,
                                    amount, self.cfg.sell_slippage_bps)
            if not res:
                log.warning("SELL FAILED for %s (%s) - will retry next cycle", p["symbol"], reason)
                return
            got, sig = res["out"] / LAMPORTS, res["sig"]
        else:
            out = jupiter.quote_out(self.cfg.jupiter_api_key, p["mint"], WSOL, amount,
                                    self.cfg.sell_slippage_bps)
            if not out:
                log.warning("dry-run sell quote failed for %s", p["symbol"])
                return
            got, sig = out / LAMPORTS, "dry-run"
            self.store.set("dry_sol", self.store.get_float("dry_sol") + got - DRY_FEE_SOL)
        remaining = p["tokens_raw"] - amount
        fields = {"tokens_raw": remaining, "sol_out": p["sol_out"] + got}
        if reason.startswith("take-profit 1"):
            fields["tp1_done"] = 1
        if reason.startswith("take-profit 2"):
            fields["tp2_done"] = 1
        if remaining <= 0 or frac >= 1:
            fields.update(status="closed", closed_at=time.time(), tokens_raw=0)
            if self.cfg.sweep_address:
                share = sweep.share_of_profit(p["sol_in"], p["sol_out"] + got, self.cfg.sweep_pct)
                if share > 0:
                    self.store.set("sweep_pending", self.store.get_float("sweep_pending") + share)
        self.store.update_position(p["id"], **fields)
        self.store.log_trade(position_id=p["id"], side="sell", mint=p["mint"], symbol=p["symbol"],
                             sol=got, tokens_raw=amount, reason=reason, signature=sig,
                             dry_run=int(not self.live))
        self.notify(f"{'[DRY] ' if not self.live else ''}SELL {p['symbol']} {frac:.0%}: {reason} "
                    f"-> {got:.4f} SOL")

    # ------------------------------------------------------------ profit sweep
    def maybe_sweep(self) -> None:
        pending = self.store.get_float("sweep_pending")
        if not self.cfg.sweep_address or pending < self.cfg.min_sweep_sol:
            return
        free = self.free_sol()
        if free is None or free - pending < self.cfg.reserve_sol:
            return  # never dip into the fee reserve
        if self.live:
            sig = sweep.send_sol(self.cfg.rpc_url, self.keypair, self.cfg.sweep_address,
                                 int(pending * LAMPORTS))
            if not sig:
                log.warning("profit sweep failed; will retry next cycle")
                return
        else:
            self.store.set("dry_sol", self.store.get_float("dry_sol") - pending)
            sig = "dry-run"
        self.store.set("sweep_pending", 0)
        self.store.set("swept_total", self.store.get_float("swept_total") + pending)
        # money leaving the wallet must not look like a loss to the kill switch
        self.store.set("peak_equity", max(0.0, self.store.get_float("peak_equity") - pending))
        self.notify(f"{'[DRY] ' if not self.live else ''}Sent {pending:.4f} SOL profit share "
                    f"to your wallet ({self.cfg.sweep_pct:.0%} of winning trades). {sig[:12]}")

    def strategy_active(self, name: str) -> bool:
        streak, last = self.store.loss_streak(name)
        paused = streak >= self.cfg.loss_streak_pause and time.time() - last < 6 * 3600
        if paused and not self.paused_strategies.get(name):
            self.notify(f"Strategy '{name}' paused for 6h after {streak} losses in a row.")
        self.paused_strategies[name] = paused
        return not paused

    def confirmed(self, passers: Dict[str, float]) -> set:
        """A token must keep passing for N cycles and must not have run up
        more than max_chase since we first saw it (no chasing pumps)."""
        now = time.time()
        for mint in list(self.seen):
            if mint not in passers:
                del self.seen[mint]
        ok = set()
        for mint, price in passers.items():
            e = self.seen.get(mint)
            if e is None:
                e = self.seen[mint] = {"n": 0, "price": price, "t": now}
            e["n"] += 1
            if e["n"] >= self.cfg.min_confirmations and price <= e["price"] * (1 + self.cfg.max_chase):
                ok.add(mint)
        return ok

    # ------------------------------------------------------------ cycle
    def manage_positions(self, positions, pairs) -> float:
        """Handles exits. Returns total mark-to-market value (SOL) of positions."""
        total = 0.0
        for p in positions:
            pair = pairs.get(p["mint"])
            if not pair:
                self.missing[p["id"]] = self.missing.get(p["id"], 0) + 1
                if self.missing[p["id"]] >= 3:
                    self.sell(p, 1.0, "no market data for 3 cycles")
                continue
            self.missing[p["id"]] = 0
            price = market.price_native(pair)
            total += p["tokens_raw"] / (10 ** p["decimals"]) * price
            peak = max(p["peak_price"], price)
            self.store.update_position(p["id"], last_price=price, peak_price=peak)
            liq = (pair.get("liquidity") or {}).get("usd")
            if risk.liquidity_exit(p["entry_liq"], liq):
                self.sell(p, 1.0, "emergency: liquidity collapsed")
                continue
            action, frac, why = risk.exit_decision(p["entry_price"], price, peak,
                                                   bool(p["tp1_done"]), bool(p["tp2_done"]), self.cfg)
            if action == "sell":
                self.sell(p, frac, why)
        return total

    def scan_and_buy(self, free: float) -> None:
        size = risk.position_size(free, self.cfg)
        if size <= 0:
            log.info("balance %.4f SOL too low for a trade", free)
            return
        fresh = market.candidate_mints() + list(self.seen.keys())
        mints = [m for m in dict.fromkeys(fresh)
                 if self.rejected.get(m, 0) < time.time() - 3600
                 and not self.store.has_open(m) and not self.store.recently_traded(m)]
        pairs = market.fetch_best_pairs(mints)
        now_ms = int(time.time() * 1000)
        active = [n for n in strategies.STRATEGIES if self.strategy_active(n)]
        scored = {}
        for mint, pair in pairs.items():
            for name in active:
                ok, _ = strategies.STRATEGIES[name](pair, now_ms)
                if ok:
                    sc, _parts = strategies.score_pair(pair, name, now_ms)
                    if sc >= self.cfg.min_score:
                        scored[mint] = (sc, name, pair)
                    break
        good = self.confirmed({m: market.price_native(v[2]) for m, v in scored.items()})
        picks = sorted(((v[0], v[1], m, v[2]) for m, v in scored.items() if m in good),
                       key=lambda x: x[0], reverse=True)
        log.info("candidates %d, passed filters+score %d, confirmed %d",
                 len(mints), len(scored), len(picks))
        for _, name, mint, pair in picks[:3]:
            rep = security.check_token(self.cfg.rpc_url, mint, self.cfg.allow_token_2022)
            if not rep.passed:
                log.info("REJECT %s: %s", mint, "; ".join(rep.fails))
                self.rejected[mint] = time.time()
                continue
            ok, why, _ = jupiter.sellability_check(self.cfg.jupiter_api_key, mint,
                                                    int(size * LAMPORTS), self.cfg.buy_slippage_bps)
            if not ok:
                log.info("REJECT %s: %s", mint, why)
                self.rejected[mint] = time.time()
                continue
            if self.buy(name, mint, pair, size, rep.decimals):
                return  # one buy per cycle

    def cycle(self) -> None:
        if self.store.get("reset_requested") == "1":
            eq = self.free_sol() or 0
            for k, v in (("halted", 0), ("halt_reason", ""), ("start_equity", eq),
                         ("peak_equity", eq), ("reset_requested", 0)):
                self.store.set(k, v)
            self.notify(f"Halt cleared. New baseline {eq:.4f} SOL.")
        positions = self.store.open_positions()
        pairs = market.fetch_best_pairs([p["mint"] for p in positions]) if positions else {}
        free = self.free_sol()
        if free is None:
            log.warning("could not read balance; skipping cycle")
            return
        pos_value = self.manage_positions(positions, pairs)
        self.maybe_sweep()
        free = self.free_sol() or free
        equity = free + pos_value

        if self.store.get("start_equity") is None:
            self.store.set("start_equity", equity)
            self.store.set("peak_equity", equity)
        start = self.store.get_float("start_equity")
        peak = max(self.store.get_float("peak_equity"), equity)
        self.store.set("peak_equity", peak)

        halted = self.store.get("halted") == "1"
        if not halted:
            stop, why = risk.should_halt(equity, peak, start, self.cfg)
            if stop:
                self.store.set("halted", 1)
                self.store.set("halt_reason", why)
                halted = True
                self.notify(f"KILL SWITCH: trading halted - {why}. Run `python bot.py --reset` to resume.")

        self.store.set("equity", equity)
        self.store.set("free_sol", free)
        self.store.set("mode", "live" if self.live else "dry")
        self.store.set("last_cycle", time.time())
        paused = self.store.get("paused") == "1"
        s = self.store.stats()
        log.info("%s equity=%.4f peak=%.4f free=%.4f open=%d closed=%d net=%+.4f SOL%s",
                 "LIVE" if self.live else "DRY", equity, peak, free,
                 len(self.store.open_positions()), s["closed"], s["net_sol"],
                 " HALTED" if halted else (" PAUSED" if paused else ""))

        if risk.can_open(len(self.store.open_positions()), halted or paused, self.cfg):
            self.scan_and_buy(free)

    def run(self) -> None:
        mode = "LIVE (real money)" if self.live else "DRY-RUN (no money moves)"
        self.notify(f"Bot started in {mode}. Wallet: {self.address or 'n/a'}")
        self.store.set("shutdown", 0)
        while True:
            try:
                self.cycle()
            except Exception as exc:
                log.exception("cycle crashed; continuing")
                self.store.set("last_error", f"{type(exc).__name__}: {exc}")
            for _ in range(self.cfg.poll_seconds):
                if self.store.get("shutdown") == "1":
                    self.notify("Bot stopped from the extension.")
                    return
                time.sleep(1)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                        handlers=[logging.StreamHandler(), logging.FileHandler("bot.log")])
    cfg = config.load()
    if not cfg.api_token:
        import secrets
        cfg.api_token = secrets.token_urlsafe(18)
        with open(".env", "a", encoding="utf-8") as fh:
            fh.write(f"\nAPI_TOKEN={cfg.api_token}\n")
        print("\nExtension token created (paste it into the extension once):")
        print(cfg.api_token, "\n")
    bot = Bot(cfg)
    if "--reset" in sys.argv:
        eq = (bot.free_sol() or 0)
        bot.store.set("halted", 0)
        bot.store.set("start_equity", eq)
        bot.store.set("peak_equity", eq)
        print(f"Reset done. Baseline equity now {eq:.4f} SOL.")
        return
    import threading
    import api
    server = api.make_server(cfg)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    log.info("Control API on http://127.0.0.1:%d (token required)", cfg.api_port)
    bot.run()


if __name__ == "__main__":
    main()
