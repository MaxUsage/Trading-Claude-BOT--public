"""Profit sweep: sends a fixed share of each winning trade's profit to YOUR wallet.

Safety:
- The destination is read from SWEEP_ADDRESS in .env at startup. The extension/API
  cannot change it or trigger a transfer anywhere else.
- Only SOL, only to that one address, never below the reserve the bot needs.
- Sweeping happens AFTER a position is fully closed and only on realized profit.
"""
import base64
import logging
from typing import Optional

from security import rpc
from wallet import b58decode

log = logging.getLogger("sweep")


def valid_address(addr: str) -> bool:
    try:
        return len(b58decode(addr)) == 32
    except ValueError:
        return False


def share_of_profit(sol_in: float, sol_out: float, pct: float) -> float:
    """Pure (tested): the amount to set aside from one closed trade."""
    profit = sol_out - sol_in
    return round(profit * pct, 9) if profit > 0 else 0.0


def send_sol(rpc_url: str, keypair, to_addr: str, lamports: int) -> Optional[str]:
    """Plain SOL transfer signed locally. Returns the signature or None.
    NOT verified against the live network in the build environment."""
    from solders.hash import Hash
    from solders.message import Message
    from solders.pubkey import Pubkey
    from solders.system_program import TransferParams, transfer
    from solders.transaction import Transaction

    bh = rpc(rpc_url, "getLatestBlockhash", [{"commitment": "confirmed"}])
    if not bh:
        return None
    blockhash = Hash.from_string(bh["value"]["blockhash"])
    ix = transfer(TransferParams(from_pubkey=keypair.pubkey(),
                                 to_pubkey=Pubkey.from_string(to_addr), lamports=lamports))
    msg = Message.new_with_blockhash([ix], keypair.pubkey(), blockhash)
    tx = Transaction([keypair], msg, blockhash)
    raw = base64.b64encode(bytes(tx)).decode()
    return rpc(rpc_url, "sendTransaction",
               [raw, {"encoding": "base64", "preflightCommitment": "confirmed"}])
