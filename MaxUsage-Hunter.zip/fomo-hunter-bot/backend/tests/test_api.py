import json, os, sys, tempfile, threading, unittest, urllib.request, urllib.error
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["JUPITER_API_KEY"] = "t"
import config, api
from store import Store


class ApiTest(unittest.TestCase):
    def setUp(self):
        os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "a.db")
        os.environ["API_TOKEN"] = "secret123"
        self.cfg = config.load()
        self.store = Store(self.cfg.db_path)
        self.srv = api.make_server(self.cfg, port=0)
        self.port = self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def tearDown(self): self.srv.shutdown()

    def call(self, path, method="GET", token="secret123"):
        req = urllib.request.Request(f"http://127.0.0.1:{self.port}{path}", method=method,
                                     data=b"" if method == "POST" else None,
                                     headers={"X-Token": token} if token is not None else {})
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read())

    def test_requires_token(self):
        self.assertEqual(self.call("/status", token="wrong")[0], 401)
        self.assertEqual(self.call("/status", token=None)[0], 401)

    def test_status_offline_when_never_ran(self):
        code, body = self.call("/status")
        self.assertEqual(code, 200); self.assertFalse(body["running"])

    def test_pause_resume_shutdown_flags(self):
        self.call("/pause", "POST"); self.assertEqual(self.store.get("paused"), "1")
        self.call("/resume", "POST"); self.assertEqual(self.store.get("paused"), "0")
        self.call("/shutdown", "POST"); self.assertEqual(self.store.get("shutdown"), "1")
        self.call("/reset", "POST"); self.assertEqual(self.store.get("reset_requested"), "1")

    def test_positions_and_unknown_route(self):
        self.store.open_position(mint="M", symbol="T", strategy="graduated", decimals=6,
                                 tokens_raw=1_000_000, sol_in=0.05, entry_price=0.05, entry_liq=1000,
                                 dry_run=1)
        self.store.update_position(1, last_price=0.06)
        code, body = self.call("/positions")
        self.assertAlmostEqual(body["positions"][0]["pnl_pct"], 0.2)
        self.assertEqual(self.call("/nope")[0], 404)

    def test_bad_host_rejected(self):
        req = urllib.request.Request(f"http://127.0.0.1:{self.port}/status",
                                     headers={"X-Token": "secret123", "Host": "evil.com"})
        try:
            urllib.request.urlopen(req, timeout=5); self.fail("should reject")
        except urllib.error.HTTPError as e:
            self.assertEqual(e.code, 403)


if __name__ == "__main__":
    unittest.main()
