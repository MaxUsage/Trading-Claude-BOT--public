import os, sys, time, tempfile, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["JUPITER_API_KEY"] = "test"
os.environ["DRY_RUN"] = "true"
os.environ["MIN_CONFIRMATIONS"] = "1"
os.environ["MIN_SWEEP_SOL"] = "0.001"
os.environ["SWEEP_ADDRESS"] = "FKzZC4BBuC7xqWFMfnVnEe7EkkxCFfx2rwygS3HJrsth"
import config, bot as botmod, market, jupiter, security, strategies

MINT = "Mint" + "x" * 36 + "pump"


def make_pair(price, liq=30000, h1=60, m5=4):
    return {"chainId": "solana", "dexId": "pumpswap",
            "pairCreatedAt": int(time.time() * 1000) - 60 * 60000,
            "baseToken": {"address": MINT, "symbol": "TST"}, "quoteToken": {"address": config.WSOL},
            "priceNative": str(price), "liquidity": {"usd": liq}, "marketCap": 200000,
            "txns": {"m5": {"buys": 40, "sells": 10}}, "volume": {"h1": 90000, "m5": 12000},
            "priceChange": {"m5": m5, "h1": h1}}


class FlowTest(unittest.TestCase):
    def setUp(self):
        os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "t.db")
        self.cfg = config.load()
        self.price = [0.00001]
        market.candidate_mints = lambda: [MINT]
        market.fetch_best_pairs = lambda mints: {MINT: make_pair(self.price[0])} if mints else {}
        # 1 SOL buys 1,000,000 tokens (6 decimals => 1.0 ui token... use raw)
        jupiter.quote_out = lambda key, i, o, amt, sl: (
            int(amt / 1e9 / self.price[0] * 1e6) if o == MINT else int(amt / 1e6 * self.price[0] * 1e9))
        jupiter.sellability_check = lambda *a, **k: (True, "ok", 1)
        ok_report = security.Report(mint=MINT, passed=True, decimals=6)
        security.check_token = lambda *a, **k: ok_report
        botmod.Bot.notify = lambda self, t: None
        self.bot = botmod.Bot(self.cfg)

    def test_full_lifecycle_tp_then_trailing(self):
        self.bot.cycle()                                  # buys
        pos = self.bot.store.open_positions()
        self.assertEqual(len(pos), 1)
        self.assertAlmostEqual(pos[0]["sol_in"], 0.045)
        self.price[0] = 0.0000135                          # +35% -> TP1 sells half
        self.bot.cycle()
        p = self.bot.store.open_positions()[0]
        self.assertEqual(p["tp1_done"], 1)
        self.assertAlmostEqual(p["tokens_raw"] / pos[0]["tokens_raw"], 0.5, places=2)
        self.price[0] = 0.00002                            # peak +100% (TP2 fires)
        self.bot.cycle()
        self.price[0] = 0.000012                           # collapse from peak -> trailing/exit
        self.bot.cycle()
        self.assertEqual(len(self.bot.store.open_positions()), 0)
        self.assertGreater(self.bot.store.stats()["net_sol"], 0)

    def test_stop_loss_and_no_reentry(self):
        self.bot.cycle()
        self.price[0] = 0.0000070                          # -30%
        self.bot.cycle()
        self.assertEqual(len(self.bot.store.open_positions()), 0)
        self.assertLess(self.bot.store.stats()["net_sol"], 0)
        self.price[0] = 0.00001
        self.bot.cycle()                                   # recently traded -> no re-entry
        self.assertEqual(len(self.bot.store.open_positions()), 0)

    def test_kill_switch_blocks_new_buys(self):
        self.bot.cycle()
        self.price[0] = 0.0000070
        self.bot.cycle()                                   # loss
        self.bot.store.set("peak_equity", 1.0)             # force a deep drawdown vs peak
        self.bot.cycle()
        self.assertEqual(self.bot.store.get("halted"), "1")

    def test_liquidity_collapse_exit(self):
        self.bot.cycle()
        market.fetch_best_pairs = lambda mints: {MINT: make_pair(self.price[0], liq=5000)} if mints else {}
        self.bot.cycle()
        self.assertEqual(len(self.bot.store.open_positions()), 0)


    def test_profit_sweep_30pct_and_kill_switch_safe(self):
        self.bot.cycle()                                   # buy 0.045
        self.price[0] = 0.0000135; self.bot.cycle()        # TP1
        self.price[0] = 0.00002;  self.bot.cycle()         # TP2
        self.price[0] = 0.000012; self.bot.cycle()         # trailing -> closed with profit
        self.assertEqual(len(self.bot.store.open_positions()), 0)
        swept = self.bot.store.get_float("swept_total")
        net = self.bot.store.stats()["net_sol"]
        self.assertGreater(swept, 0)
        self.assertLessEqual(swept, net * 0.30 + 1e-9)     # never more than 30% of profit
        self.assertNotEqual(self.bot.store.get("halted"), "1")

    def test_loss_never_sweeps(self):
        self.bot.cycle(); self.price[0] = 0.000007; self.bot.cycle()
        self.assertEqual(self.bot.store.get_float("swept_total"), 0.0)
        self.assertEqual(self.bot.store.get_float("sweep_pending"), 0.0)


class ConfirmTest(FlowTest):
    def setUp(self):
        super().setUp(); self.bot.cfg.min_confirmations = 2

    def test_needs_two_sightings(self):
        self.bot.cycle()
        self.assertEqual(len(self.bot.store.open_positions()), 0)
        self.bot.cycle()
        self.assertEqual(len(self.bot.store.open_positions()), 1)

    def test_does_not_chase_a_pump(self):
        self.bot.cycle()
        self.price[0] *= 1.25                              # +25% between sightings
        self.bot.cycle()
        self.assertEqual(len(self.bot.store.open_positions()), 0)

    # inherited lifecycle tests assume instant buys; skip them here
    test_full_lifecycle_tp_then_trailing = None
    test_stop_loss_and_no_reentry = None
    test_kill_switch_blocks_new_buys = None
    test_liquidity_collapse_exit = None
    test_profit_sweep_30pct_and_kill_switch_safe = None
    test_loss_never_sweeps = None


class StreakTest(FlowTest):
    def test_strategy_pauses_after_losing_streak(self):
        st = self.bot.store
        for i in range(4):
            pid = st.open_position(mint=f"M{i}", symbol="X", strategy="graduated", decimals=6,
                                   tokens_raw=1, sol_in=0.05, entry_price=1, entry_liq=1, dry_run=1)
            st.update_position(pid, status="closed", sol_out=0.03, closed_at=time.time())
        self.assertFalse(self.bot.strategy_active("graduated"))
        self.assertTrue(self.bot.strategy_active("trending"))
        self.bot.cycle()                                   # graduated paused -> only trending may buy
        pos = st.open_positions()
        self.assertEqual(len(pos), 1)
        self.assertEqual(pos[0]["strategy"], "trending")


if __name__ == "__main__":
    unittest.main()
