import os, sys, time, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import config, risk, strategies, wallet
from security import holder_concentration


def cfg():
    os.environ.pop("DRY_RUN", None)
    return config.load()


class RiskTests(unittest.TestCase):
    def setUp(self): self.c = cfg()

    def test_position_size_aggressive(self):
        # 0.1 SOL, 0.01 reserve, 50% -> 0.045
        self.assertAlmostEqual(risk.position_size(0.10, self.c), 0.045)

    def test_position_size_too_small(self):
        self.assertEqual(risk.position_size(0.015, self.c), 0.0)
        self.assertEqual(risk.position_size(0.005, self.c), 0.0)

    def test_position_size_capped(self):
        self.assertEqual(risk.position_size(100, self.c), 5.0)

    def test_halt_from_peak(self):
        self.assertTrue(risk.should_halt(0.059, 0.10, 0.10, self.c)[0])
        self.assertFalse(risk.should_halt(0.07, 0.10, 0.10, self.c)[0])

    def test_halt_from_start_even_if_peak_low(self):
        self.assertTrue(risk.should_halt(0.05, 0.08, 0.10, self.c)[0])

    def test_can_open(self):
        self.assertTrue(risk.can_open(1, False, self.c))
        self.assertFalse(risk.can_open(2, False, self.c))
        self.assertFalse(risk.can_open(0, True, self.c))

    def test_stop_loss(self):
        a, f, _ = risk.exit_decision(1.0, 0.74, 1.0, False, False, self.c)
        self.assertEqual((a, f), ("sell", 1.0))

    def test_no_stop_at_minus_20(self):
        self.assertEqual(risk.exit_decision(1.0, 0.80, 1.0, False, False, self.c)[0], "hold")

    def test_tp1_then_tp2_then_trailing(self):
        a, f, r = risk.exit_decision(1.0, 1.31, 1.31, False, False, self.c)
        self.assertEqual((a, f), ("sell", 0.5)); self.assertIn("take-profit 1", r)
        a, f, r = risk.exit_decision(1.0, 1.61, 1.61, True, False, self.c)
        self.assertIn("take-profit 2", r)
        a, f, r = risk.exit_decision(1.0, 1.9, 2.5, True, True, self.c)  # 24% below peak
        self.assertEqual((a, f), ("sell", 1.0)); self.assertIn("trailing", r)

    def test_trailing_not_active_before_tp1(self):
        self.assertEqual(risk.exit_decision(1.0, 1.1, 1.25, False, False, self.c)[0], "hold")

    def test_liquidity_exit(self):
        self.assertTrue(risk.liquidity_exit(20000, 9000))
        self.assertFalse(risk.liquidity_exit(20000, 15000))
        self.assertFalse(risk.liquidity_exit(None, 100))


def pair(**o):
    now = int(time.time() * 1000)
    p = {"dexId": "pumpswap", "pairCreatedAt": now - 60 * 60000,
         "baseToken": {"address": "ABC" + "x" * 30 + "pump", "symbol": "T"},
         "liquidity": {"usd": 30000}, "marketCap": 200000,
         "txns": {"m5": {"buys": 40, "sells": 15}},
         "volume": {"h1": 90000, "m5": 12000}, "priceChange": {"m5": 4, "h1": 60}}
    p.update(o); return p


class StrategyTests(unittest.TestCase):
    def test_graduated_pass(self):
        self.assertTrue(strategies.evaluate_graduated(pair())[0])

    def test_graduated_rejects_exhausted_pump(self):
        ok, why = strategies.evaluate_graduated(pair(priceChange={"m5": 4, "h1": 500}))
        self.assertFalse(ok); self.assertTrue(any("exhausted" in w for w in why))

    def test_graduated_rejects_low_liquidity(self):
        self.assertFalse(strategies.evaluate_graduated(pair(liquidity={"usd": 5000}))[0])

    def test_graduated_rejects_non_pump_mint(self):
        p = pair(); p["baseToken"]["address"] = "ABC" + "x" * 34
        self.assertFalse(strategies.evaluate_graduated(p)[0])

    def test_missing_data_fails_not_passes(self):
        self.assertFalse(strategies.evaluate_graduated({})[0])
        self.assertFalse(strategies.evaluate_trending({})[0])

    def test_trending_pass(self):
        p = pair(dexId="raydium", pairCreatedAt=int(time.time() * 1000) - 5 * 3600 * 1000,
                 priceChange={"m5": 2, "h1": 40})
        self.assertTrue(strategies.evaluate_trending(p)[0])


class MiscTests(unittest.TestCase):
    def test_base58_roundtrip(self):
        for raw in (b"\x00\x00hello", bytes(range(64)), b"\xff" * 32):
            self.assertEqual(wallet.b58decode(wallet.b58encode(raw)), raw)

    def test_holders_ok(self):
        top1, top9 = holder_concentration([800, 20, 15, 10, 10, 10, 10, 10, 10, 10, 5], 1000)
        self.assertAlmostEqual(top1, 0.02); self.assertLess(top9, 0.35)

    def test_holders_whale(self):
        top1, _ = holder_concentration([500, 200, 10, 10], 1000)
        self.assertGreater(top1, 0.10)

    def test_holders_insufficient(self):
        self.assertIsNone(holder_concentration([100, 50], 1000))

    def test_live_needs_both_flags(self):
        c = cfg(); c.dry_run = False; c.confirm_real_money = False
        self.assertFalse(config.live_trading_enabled(c))
        c.confirm_real_money = True
        self.assertTrue(config.live_trading_enabled(c))
        c.dry_run = True
        self.assertFalse(config.live_trading_enabled(c))


class ScoreAndSweepTests(unittest.TestCase):
    def test_good_pair_scores_high(self):
        sc, parts = strategies.score_pair(pair(), "graduated")
        self.assertGreaterEqual(sc, 80)

    def test_chasing_pump_loses_momentum_points(self):
        sc, parts = strategies.score_pair(pair(priceChange={"m5": 60, "h1": 60}), "graduated")
        self.assertEqual(parts["momentum"], 0.0)

    def test_wash_like_volume_penalised(self):
        good, _ = strategies.score_pair(pair(), "graduated")
        bad, parts = strategies.score_pair(pair(volume={"h1": 90000, "m5": 200000}), "graduated")
        self.assertLess(parts["wash_penalty"], 0); self.assertLess(bad, good)

    def test_dust_trades_penalised(self):
        _, parts = strategies.score_pair(pair(volume={"h1": 90000, "m5": 100}), "graduated")
        self.assertLess(parts["wash_penalty"], 0)

    def test_empty_pair_scores_zero(self):
        self.assertEqual(strategies.score_pair({}, "trending")[0], 0.0)

    def test_share_of_profit(self):
        import sweep
        self.assertAlmostEqual(sweep.share_of_profit(0.05, 0.08, 0.30), 0.009)
        self.assertEqual(sweep.share_of_profit(0.05, 0.04, 0.30), 0.0)
        self.assertEqual(sweep.share_of_profit(0.05, 0.05, 0.30), 0.0)

    def test_address_validation(self):
        import sweep
        self.assertTrue(sweep.valid_address("FKzZC4BBuC7xqWFMfnVnEe7EkkxCFfx2rwygS3HJrsth"))
        self.assertFalse(sweep.valid_address("FKzZC4BBuC7xqWFMf"))  # far too short
        self.assertFalse(sweep.valid_address("not-an-address-0OIl"))


if __name__ == "__main__":
    unittest.main()
