"""DexScreener market data. Endpoints verified against docs.dexscreener.com:
  GET /token-profiles/latest/v1      (60 req/min)
  GET /token-boosts/latest/v1        (60 req/min)
  GET /token-boosts/top/v1           (60 req/min)
  GET /latest/dex/tokens/{a,b,c}     (300 req/min, max 30 addresses)
No data is ever invented: on any failure we return nothing and the bot idles.
"""
import logging
from typing import Dict, List

import requests

from config import WSOL

log = logging.getLogger("market")
BASE = "https://api.dexscreener.com"


def _get(path: str):
    try:
        r = requests.get(BASE + path, timeout=15)
        if r.status_code == 429:
            log.warning("DexScreener rate limit hit on %s", path)
            return None
        r.raise_for_status()
        return r.json()
    except Exception as exc:  # network errors must never crash the bot
        log.warning("DexScreener request failed %s: %s", path, exc)
        return None


def candidate_mints() -> List[str]:
    """Solana token addresses from profile/boost feeds (candidates only;
    boosts are paid promotion, so they are NOT a buy signal)."""
    seen, out = set(), []
    for path in ("/token-profiles/latest/v1", "/token-boosts/latest/v1", "/token-boosts/top/v1"):
        data = _get(path)
        if not isinstance(data, list):
            continue
        for item in data:
            if item.get("chainId") == "solana":
                addr = item.get("tokenAddress")
                if addr and addr not in seen:
                    seen.add(addr)
                    out.append(addr)
    return out


def fetch_best_pairs(mints: List[str]) -> Dict[str, Dict]:
    """Best SOL-quoted pair per mint (highest liquidity)."""
    best: Dict[str, Dict] = {}
    for i in range(0, len(mints), 30):
        chunk = mints[i:i + 30]
        data = _get("/latest/dex/tokens/" + ",".join(chunk))
        if not data:
            continue
        for pair in data.get("pairs") or []:
            if pair.get("chainId") != "solana":
                continue
            if (pair.get("quoteToken") or {}).get("address") != WSOL:
                continue
            mint = (pair.get("baseToken") or {}).get("address")
            liq = ((pair.get("liquidity") or {}).get("usd")) or 0
            cur = best.get(mint)
            if cur is None or liq > ((cur.get("liquidity") or {}).get("usd") or 0):
                best[mint] = pair
    return best


def price_native(pair: Dict) -> float:
    try:
        return float(pair.get("priceNative"))
    except (TypeError, ValueError):
        return 0.0
