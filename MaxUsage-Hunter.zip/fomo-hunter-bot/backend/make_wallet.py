"""Creates a NEW wallet for the bot, locally on your PC.

    python make_wallet.py              saves the key into .env, prints ONLY the address
    python make_wallet.py --show-key   also prints the key once, so you can import
                                       the wallet into Phantom (as a separate account)

Never use your main wallet here. Fund this one with only what you can lose.
Back up the key somewhere offline: if you lose it, the funds are gone.
"""
import os
import sys

from solders.keypair import Keypair

from wallet import b58encode

if os.path.exists(".env") and "BOT_PRIVATE_KEY=" in open(".env", encoding="utf-8").read():
    sys.exit("BOT_PRIVATE_KEY already exists in .env. Refusing to overwrite it.")

kp = Keypair()
secret = b58encode(bytes(kp))  # 64-byte secret, base58 (Phantom import format)
with open(".env", "a", encoding="utf-8") as fh:
    fh.write(f"\nBOT_PRIVATE_KEY={secret}\n")

print("Bot wallet created. Send SOL to this address:")
print(str(kp.pubkey()))
if "--show-key" in sys.argv:
    print("\nPRIVATE KEY (do not share, do not screenshot):")
    print(secret)
else:
    print("\nKey saved to .env (not shown). Use --show-key on a NEW run only if you need it for Phantom.")
