"""On-chain safety checks using standard Solana JSON-RPC methods
(getAccountInfo, getTokenLargestAccounts, getBalance). Every check reports
pass / fail / unavailable. A single failed mandatory check rejects the token;
'unavailable' on a mandatory check also rejects (we do not guess).

No check here proves a token is safe. They only remove obvious traps.
"""
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import requests

log = logging.getLogger("security")
TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
TOKEN_2022_PROGRAM = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"


@dataclass
class Report:
    mint: str
    passed: bool = False
    decimals: int = 0
    checks: Dict[str, str] = field(default_factory=dict)  # name -> "pass"/"fail: why"/"unavailable"
    fails: List[str] = field(default_factory=list)


def rpc(url: str, method: str, params: list):
    try:
        r = requests.post(url, json={"jsonrpc": "2.0", "id": 1, "method": method, "params": params},
                          timeout=15)
        r.raise_for_status()
        body = r.json()
        if "error" in body:
            log.warning("RPC %s error: %s", method, body["error"])
            return None
        return body.get("result")
    except Exception as exc:
        log.warning("RPC %s failed: %s", method, exc)
        return None


def get_sol_balance(rpc_url: str, address: str) -> Optional[float]:
    res = rpc(rpc_url, "getBalance", [address, {"commitment": "confirmed"}])
    if not res:
        return None
    return res["value"] / 1e9


def holder_concentration(amounts: List[float], supply: float):
    """Pure function (tested). Largest account is assumed to be the liquidity
    pool / curve vault and is excluded; then we look at the real holders.
    Returns (top1_pct, top9_pct) as fractions of supply."""
    if supply <= 0 or len(amounts) < 3:
        return None
    ordered = sorted(amounts, reverse=True)[1:]  # drop the pool-like top account
    top1 = ordered[0] / supply
    top9 = sum(ordered[:9]) / supply
    return top1, top9


def check_token(rpc_url: str, mint: str, allow_token_2022: bool = False) -> Report:
    rep = Report(mint=mint)

    # 1) Mint account: program, authorities, decimals, supply
    info = rpc(rpc_url, "getAccountInfo", [mint, {"encoding": "jsonParsed"}])
    value = (info or {}).get("value")
    parsed = ((value or {}).get("data") or {}).get("parsed", {}).get("info") if value else None
    if not parsed:
        rep.checks["mint_account"] = "unavailable"
        rep.fails.append("could not read mint account")
        return rep
    owner = value.get("owner")
    rep.decimals = int(parsed.get("decimals", 0))
    if owner == TOKEN_2022_PROGRAM and not allow_token_2022:
        rep.checks["token_program"] = "fail: Token-2022 (extensions can add fees/delegates)"
        rep.fails.append("Token-2022 mint")
    elif owner not in (TOKEN_PROGRAM, TOKEN_2022_PROGRAM):
        rep.checks["token_program"] = "fail: unknown owner program"
        rep.fails.append("unknown token program")
    else:
        rep.checks["token_program"] = "pass"

    if parsed.get("mintAuthority"):
        rep.checks["mint_authority"] = "fail: creator can mint more supply"
        rep.fails.append("mint authority not revoked")
    else:
        rep.checks["mint_authority"] = "pass"
    if parsed.get("freezeAuthority"):
        rep.checks["freeze_authority"] = "fail: creator can freeze wallets"
        rep.fails.append("freeze authority not revoked")
    else:
        rep.checks["freeze_authority"] = "pass"

    # 2) Holder concentration (heuristic, see holder_concentration)
    supply = float(parsed.get("supply", 0)) / (10 ** rep.decimals) if rep.decimals >= 0 else 0
    largest = rpc(rpc_url, "getTokenLargestAccounts", [mint])
    if not largest or not largest.get("value"):
        rep.checks["holders"] = "unavailable"
        rep.fails.append("holder data unavailable")
    else:
        amounts = [float(a.get("uiAmount") or 0) for a in largest["value"]]
        conc = holder_concentration(amounts, supply)
        if conc is None:
            rep.checks["holders"] = "unavailable"
            rep.fails.append("not enough holder data")
        else:
            top1, top9 = conc
            if top1 > 0.10 or top9 > 0.35:
                rep.checks["holders"] = f"fail: top holder {top1:.1%}, next-9 {top9:.1%} of supply"
                rep.fails.append("holders too concentrated")
            else:
                rep.checks["holders"] = f"pass (top {top1:.1%}, next-9 {top9:.1%})"

    rep.passed = not rep.fails
    return rep
