@echo off
cd /d "%~dp0backend"
python bot.py
pause
