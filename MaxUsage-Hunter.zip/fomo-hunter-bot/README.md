# FOMO Hunter Bot (backend v1)

Trades Solana memecoins on-chain through Jupiter from its OWN wallet.
It does not control FOMO.family (no public API). Start in DRY-RUN.

## Setup (Windows)
1. Install Python 3.12 from python.org (tick "Add to PATH").
2. Open a terminal in `backend/` and run: `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`, then fill in:
   - JUPITER_API_KEY  (free: https://developers.jup.ag/portal)
   - RPC_URL          (free Helius key -> full URL)
4. Create the bot wallet: `python make_wallet.py`  (prints the address only)
   Use `--show-key` once if you want to import it into Phantom as a separate account.
5. Run tests: `python -m unittest discover -s tests -v`
6. Start in dry-run: `python bot.py`  (or double-click START_BOT.bat)
   Let it run for several days. Read bot.log. Nothing real is bought.

## The Chrome extension (control panel)
1. Start the bot once. It prints an extension token and saves it as API_TOKEN in `.env`.
2. Chrome -> `chrome://extensions` -> turn on Developer mode -> Load unpacked -> pick the `extension` folder.
3. Click the extension icon, paste the token, Save and connect.
4. Toolbar badge: ON (running), II (buying paused), STOP (halted), OFF (bot not running), ? (no token yet).
- Pause buying: stops new buys, still manages and sells open positions.
- Stop bot: shuts the bot down cleanly (open positions stay open and are NOT sold).
- Clear halt: re-baselines after the kill switch fired (takes effect next cycle).
- Chrome notifications for every buy/sell, the kill switch, and the bot going offline.
- The extension only talks to 127.0.0.1:8787 on your PC with the secret token. It cannot move funds or read keys.
- The bot must be running (START_BOT.bat). Chrome cannot start it for you.

## How to stop / check the bot without the extension
- Stop: close the black bot window, or press Ctrl+C in it.
- Running? The window prints a status line every cycle; `bot.log` has the history.

## Going live (only after dry-run looks sane)
1. Send a SMALL amount of SOL to the bot wallet address.
2. In `.env` set `DRY_RUN=false` AND `I_UNDERSTAND_REAL_MONEY=yes`.
3. Restart the bot.

## Safety rules built in
- Kill switch: 40% below peak equity OR 40% below start -> no new buys until `python bot.py --reset`.
- Per trade: 50% of free balance (keeps 0.01 SOL reserve), hard cap 5 SOL, max 2 positions.
- Stop-loss -25%. Take-profit +30% (sell 50%), +60% (sell half of rest), then 20% trailing stop.
- Emergency exit if pool liquidity halves. Never re-enters a token traded in the last 6h.
- Rejects: mint/freeze authority not revoked, Token-2022, concentrated holders,
  no sell route / bad round-trip quote, missing data (unknown = reject).

## Smarter picking (v2)
- Every candidate gets a transparent 0-100 score (buy pressure, volume acceleration, pool depth,
  momentum sanity, activity, age) with penalties for wash-trading-like patterns. Needs 60+.
- Must pass the filters on 2 consecutive checks and must not have risen 15% since first seen (no chasing).
- A strategy that loses 4 trades in a row is paused for 6 hours.

## Profit sweep
- 30% of each WINNING trade's profit is sent to SWEEP_ADDRESS once the trade is fully closed.
  The other 70% stays in the bot wallet and compounds. Losses never trigger a sweep.
- The address is fixed in .env at startup; the extension cannot change it or send funds anywhere.
- Never dips below the 0.01 SOL fee reserve. Practice mode only simulates it.
- Solana addresses have NO checksum: compare the address with Phantom's Receive screen
  (first and last 6 characters) before going live.

## NOT done / limitations (read this)
- The SOL transfer code for sweeping is unverified on the live network (no internet in the build environment).
- Live Jupiter calls, signing and RPC calls are UNTESTED against the real network
  (the build environment had no internet). Logic is unit-tested with mocks.
- "Graduated" is a heuristic (see strategies.py). A proper graduation listener is not built.
- Candidates come from DexScreener profile/boost lists -> partial coverage of new tokens.
- Not built yet: multi-bot budgets, FOMO deep links (no documented URL format).
- Extension is untested in a real Chrome (build environment had none); JS syntax-checked only.
- Free Jupiter key = 1 request/second; free RPC may rate-limit.
- No strategy here is proven profitable. Most memecoin bots lose money.
