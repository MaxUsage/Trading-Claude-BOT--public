const $ = (id) => document.getElementById(id);
let timer = null, armedStop = null, armedReset = null, lastStatus = null;

function h(tag, props = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") el.className = v; else if (k === "text") el.textContent = v; else el.setAttribute(k, v);
  }
  kids.flat().forEach((k) => k != null && el.append(k.nodeType ? k : document.createTextNode(String(k))));
  return el;
}
const sol = (n) => (n == null ? "-" : Number(n).toFixed(4));
const pct = (n) => (n == null ? "-" : (n >= 0 ? "+" : "") + (n * 100).toFixed(1) + "%");
function ago(s) {
  if (s == null) return "never";
  if (s < 60) return s + "s ago";
  if (s < 3600) return Math.floor(s / 60) + " min ago";
  return Math.floor(s / 3600) + " h ago";
}
function clock(ts) {
  const d = new Date(ts * 1000);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function setStatus(kind, text) {
  $("status").className = "status " + kind;
  $("statusText").textContent = text;
}

function banner(text, info) {
  const b = $("banner");
  b.hidden = !text;
  b.className = "banner" + (info ? " info" : "");
  b.textContent = text || "";
}

function renderStatus(s) {
  lastStatus = s;
  const state = s.halted ? "halted" : !s.running ? "offline" : s.paused ? "paused" : "running";
  setStatus(state, { halted: "Halted", offline: "Not running", paused: "Buying paused", running: "Running" }[state]);

  const live = s.mode === "live";
  $("mode").className = "mode" + (live ? " live" : "");
  $("mode").textContent = live ? "Live trading with real money" : "Practice mode, no real money";
  $("equity").textContent = sol(s.equity);
  const base = s.start || 0;
  if (base > 0) {
    const d = s.equity / base - 1;
    $("delta").className = "delta " + (d >= 0 ? "up" : "down");
    $("delta").textContent = `${pct(d)} since start (${(s.equity - base >= 0 ? "+" : "") + sol(s.equity - base)} SOL)`;
  } else { $("delta").textContent = ""; }
  $("beat").textContent = s.running ? `Last check ${ago(s.seconds_since_check)}` :
    s.seconds_since_check != null ? `Last seen ${ago(s.seconds_since_check)}` : "The bot has not reported yet";

  $("peak").textContent = sol(s.peak);
  $("free").textContent = sol(s.free_sol);
  $("wl").textContent = `${s.stats.wins} / ${s.stats.closed}`;

  if (s.halted) banner("Trading halted: " + (s.halt_reason || "loss limit reached") + ". No new buys until you clear the halt.");
  else if (!s.running) banner("The bot is not responding. Start it with START_BOT.bat.", true);
  else if (s.last_error) banner("Last error: " + s.last_error, true);
  else banner("");

  $("pauseBtn").textContent = s.paused ? "Resume buying" : "Pause buying";
  $("resetBtn").hidden = !s.halted;
}

function renderPositions(list) {
  const box = $("positions"); box.replaceChildren();
  if (!list.length) { box.append(h("div", { class: "empty", text: "No open positions. The bot buys only when a token passes every check." })); return; }
  list.forEach((p) => {
    const cls = p.pnl_pct == null ? "" : p.pnl_pct >= 0 ? "up" : "down";
    const copy = h("button", { class: "mini", text: "Copy address" });
    copy.addEventListener("click", async () => { await navigator.clipboard.writeText(p.mint); copy.textContent = "Copied"; setTimeout(() => (copy.textContent = "Copy address"), 1200); });
    box.append(h("div", { class: "pos" },
      h("div", {}, h("span", { class: "sym", text: p.symbol }), h("div", { class: "sub", text: `${p.strategy}, spent ${sol(p.sol_in)} SOL` })),
      h("div", { class: "pnl " + cls, text: pct(p.pnl_pct) }),
      h("div", { class: "acts" }, copy,
        h("a", { class: "mini", href: "https://dexscreener.com/solana/" + encodeURIComponent(p.mint), target: "_blank", rel: "noopener", text: "Open chart" }),
        h("span", { class: "sub", text: `worth ${sol(p.value_sol)} SOL` + (p.tp1_done ? ", partly sold" : "") }))));
  });
}

function renderTrades(list) {
  const box = $("trades"); box.replaceChildren();
  if (!list.length) { box.append(h("div", { class: "empty", text: "No trades yet." })); return; }
  list.slice(0, 8).forEach((t) => {
    box.append(h("div", { class: "trade" },
      h("span", { class: "t", text: clock(t.ts) }),
      h("div", {}, h("span", { class: t.side, text: (t.dry_run ? "Practice " : "") + (t.side === "buy" ? "buy " : "sell ") }), t.symbol,
        h("div", { class: "why", text: t.reason })),
      h("span", { text: sol(t.sol) + " SOL" })));
  });
}

async function refresh() {
  try {
    const [s, p, t] = await Promise.all([call("/status"), call("/positions"), call("/trades")]);
    renderStatus(s); renderPositions(p.positions); renderTrades(t.trades);
  } catch (e) {
    if (e.message === "no-token") return showSettings("");
    if (e.message === "bad-token") return showSettings("The bot rejected this token. Copy it again from the .env file (API_TOKEN).");
    setStatus("offline", "Not running");
    banner("Cannot reach the bot on this computer. Start it with START_BOT.bat, then reopen this panel.", true);
  }
}

async function act(path) { try { await call(path, "POST"); } catch (e) { banner("Action failed: " + e.message); } refresh(); }

$("pauseBtn").addEventListener("click", () => act(lastStatus && lastStatus.paused ? "/resume" : "/pause"));
$("stopBtn").addEventListener("click", (ev) => {
  if (armedStop) { clearTimeout(armedStop); armedStop = null; ev.target.classList.remove("armed"); ev.target.textContent = "Stop bot"; act("/shutdown"); return; }
  ev.target.classList.add("armed"); ev.target.textContent = "Click again to stop";
  armedStop = setTimeout(() => { armedStop = null; ev.target.classList.remove("armed"); ev.target.textContent = "Stop bot"; }, 4000);
});
$("resetBtn").addEventListener("click", (ev) => {
  if (armedReset) { clearTimeout(armedReset); armedReset = null; ev.target.textContent = "Clear halt"; act("/reset"); return; }
  ev.target.textContent = "Click again to clear";
  armedReset = setTimeout(() => { armedReset = null; ev.target.textContent = "Clear halt"; }, 4000);
});

async function showSettings(msg) {
  const { token = "", port = 8787 } = await getConfig();
  $("token").value = token; $("port").value = port; $("setErr").textContent = msg || "";
  $("main").hidden = true; $("settings").hidden = false; clearInterval(timer);
}
$("gear").addEventListener("click", () => showSettings(""));
$("cancel").addEventListener("click", () => { $("settings").hidden = true; $("main").hidden = false; start(); });
$("save").addEventListener("click", async () => {
  const token = $("token").value.trim(), port = parseInt($("port").value, 10) || 8787;
  if (!token) { $("setErr").textContent = "Paste the token first."; return; }
  if (port !== 8787) { $("setErr").textContent = "This version only allows port 8787 (set in the extension's permissions)."; return; }
  await chrome.storage.local.set({ token, port });
  $("settings").hidden = true; $("main").hidden = false; start();
});

function start() { clearInterval(timer); refresh(); timer = setInterval(refresh, 3000); }
start();
