// Shared by popup and background. Talks ONLY to the bot on this computer.
async function getConfig() {
  const { token = "", port = 8787 } = await chrome.storage.local.get(["token", "port"]);
  return { token, port };
}

async function call(path, method = "GET") {
  const { token, port } = await getConfig();
  if (!token) throw new Error("no-token");
  const res = await fetch(`http://127.0.0.1:${port}${path}`, {
    method,
    headers: { "X-Token": token },
    cache: "no-store",
  });
  if (res.status === 401) throw new Error("bad-token");
  if (!res.ok) throw new Error("http-" + res.status);
  return res.json();
}
