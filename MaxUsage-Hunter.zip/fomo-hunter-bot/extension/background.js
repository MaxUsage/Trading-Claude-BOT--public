importScripts("api-client.js");

const ALARM = "poll-bot";

chrome.runtime.onInstalled.addListener(schedule);
chrome.runtime.onStartup.addListener(schedule);
function schedule() {
  chrome.alarms.create(ALARM, { periodInMinutes: 0.5 }); // Chrome minimum is 30 s
  poll();
}
chrome.alarms.onAlarm.addListener((a) => a.name === ALARM && poll());

function badge(text, color) {
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color });
}

function notify(id, title, message) {
  chrome.notifications.create(id, {
    type: "basic", iconUrl: "icons/icon128.png", title, message, priority: 2,
  });
}

async function poll() {
  const mem = await chrome.storage.local.get(["lastTradeId", "lastState"]);
  let state = "offline";
  try {
    const s = await call("/status");
    state = s.halted ? "halted" : !s.running ? "offline" : s.paused ? "paused" : "running";

    if (state === "running") badge("ON", "#34C98B");
    else if (state === "paused") badge("II", "#E8B14C");
    else if (state === "halted") badge("STOP", "#EF5E6C");
    else badge("OFF", "#6B7086");

    if (state === "halted" && mem.lastState !== "halted") {
      notify("halt", "Trading halted", s.halt_reason || "Kill switch triggered. Open the panel to review.");
    }

    const { trades } = await call("/trades");
    if (trades.length) {
      const newest = trades[0].id;
      if (mem.lastTradeId !== undefined) {
        trades.filter((t) => t.id > mem.lastTradeId).slice(0, 3).reverse().forEach((t) => {
          const tag = t.dry_run ? "Practice " : "";
          notify("trade-" + t.id, `${tag}${t.side === "buy" ? "Bought" : "Sold"} ${t.symbol}`,
                 `${t.sol.toFixed(4)} SOL - ${t.reason}`);
        });
      }
      await chrome.storage.local.set({ lastTradeId: newest });
    } else if (mem.lastTradeId === undefined) {
      await chrome.storage.local.set({ lastTradeId: 0 });
    }
  } catch (e) {
    if (e.message === "no-token") badge("?", "#6B7086");
    else if (e.message === "bad-token") badge("KEY", "#E8B14C");
    else {
      badge("OFF", "#6B7086");
      if (mem.lastState === "running" || mem.lastState === "paused") {
        notify("offline", "Bot is not running", "The bot stopped responding. Restart it with START_BOT.bat.");
      }
    }
  }
  await chrome.storage.local.set({ lastState: state });
}
